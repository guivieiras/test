export declare class PactEnvironment {
    readonly cwd: string;
    isWindows(platform?: string): boolean;
}
declare const _default: PactEnvironment;
export default _default;
