"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var pino = require("pino");
var pkg = require('../package.json');
var DEFAULT_LEVEL = (process.env.LOGLEVEL || 'info');
var createLogger = function (level) {
    if (level === void 0) { level = DEFAULT_LEVEL; }
    return pino({
        level: level.toLowerCase(),
        prettyPrint: {
            messageFormat: "pact-node@" + pkg.version + ": {msg}",
            translateTime: true,
        },
    });
};
var logger = createLogger();
exports.setLogLevel = function (wantedLevel) {
    if (wantedLevel) {
        logger.level =
            typeof wantedLevel === 'string'
                ? wantedLevel.toLowerCase()
                : logger.levels.labels[wantedLevel];
    }
    return logger.levels.values[logger.level];
};
exports.verboseIsImplied = function () {
    return logger.level === 'trace' || logger.level === 'debug';
};
exports.default = logger;
//# sourceMappingURL=logger.js.map