import pino = require('pino');
export declare type Logger = pino.Logger;
export declare type LogLevels = pino.Level;
declare const logger: pino.Logger;
export declare const setLogLevel: (wantedLevel?: number | "error" | "fatal" | "warn" | "info" | "debug" | "trace" | undefined) => number | void;
export declare const verboseIsImplied: () => boolean;
export default logger;
