"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var q = require("q");
var logger_1 = require("./logger");
var spawn_1 = require("./spawn");
var pact_standalone_1 = require("./pact-standalone");
var spawn_2 = require("./spawn");
var _ = require("underscore");
var checkTypes = require('check-types');
var CannotDeployError = (function (_super) {
    __extends(CannotDeployError, _super);
    function CannotDeployError(output) {
        var _this = _super.call(this, 'can-i-deploy result: it is not safe to deploy') || this;
        _this.name = 'CannotDeployError';
        _this.output = output;
        return _this;
    }
    return CannotDeployError;
}(Error));
exports.CannotDeployError = CannotDeployError;
var CanDeploy = (function () {
    function CanDeploy(options) {
        this.__argMapping = {
            name: '--pacticipant',
            version: '--version',
            latest: '--latest',
            to: '--to',
            pactBroker: '--broker-base-url',
            pactBrokerToken: '--broker-token',
            pactBrokerUsername: '--broker-username',
            pactBrokerPassword: '--broker-password',
            output: '--output',
            verbose: '--verbose',
            retryWhileUnknown: '--retry-while-unknown',
            retryInterval: '--retry-interval',
        };
        options = options || {};
        options.timeout = options.timeout || 60000;
        if (!options.output) {
            options.output = 'json';
        }
        checkTypes.assert.nonEmptyArray(options.pacticipants, 'Must provide at least one pacticipant');
        checkTypes.assert.nonEmptyString(options.pactBroker, 'Must provide the pactBroker argument');
        options.pactBrokerToken !== undefined &&
            checkTypes.assert.nonEmptyString(options.pactBrokerToken);
        options.pactBrokerUsername !== undefined &&
            checkTypes.assert.string(options.pactBrokerUsername);
        options.pactBrokerPassword !== undefined &&
            checkTypes.assert.string(options.pactBrokerPassword);
        if (options.verbose === undefined && logger_1.verboseIsImplied()) {
            options.verbose = true;
        }
        if ((options.pactBrokerUsername && !options.pactBrokerPassword) ||
            (options.pactBrokerPassword && !options.pactBrokerUsername)) {
            throw new Error('Must provide both Pact Broker username and password. None needed if authentication on Broker is disabled.');
        }
        this.options = options;
    }
    CanDeploy.convertForSpawnBinary = function (options) {
        return _.flatten([_.omit(options, 'pacticipants')].concat(options.pacticipants.map(function (_a) {
            var name = _a.name, latest = _a.latest, version = _a.version;
            return [
                { name: name },
                version
                    ? { version: version }
                    : {
                        latest: latest === true ? spawn_2.PACT_NODE_NO_VALUE : latest,
                    },
            ];
        })));
    };
    CanDeploy.prototype.canDeploy = function () {
        var _this = this;
        logger_1.default.info("Asking broker at " + this.options.pactBroker + " if it is possible to deploy");
        var deferred = q.defer();
        var instance = spawn_1.default.spawnBinary(pact_standalone_1.default.brokerPath, [
            { cliVerb: 'can-i-deploy' }
        ].concat(CanDeploy.convertForSpawnBinary(this.options)), this.__argMapping);
        var output = [];
        instance.stdout.on('data', function (l) { return output.push(l); });
        instance.stderr.on('data', function (l) { return output.push(l); });
        instance.once('close', function (code) {
            var result = output.join('\n');
            if (_this.options.output === 'json') {
                try {
                    var startIndex = output.findIndex(function (l) {
                        return l.toString().startsWith('{');
                    });
                    if (startIndex === -1) {
                        logger_1.default.error("can-i-deploy produced no json output:\n" + result);
                        return deferred.reject(new Error(result));
                    }
                    if (startIndex !== 0) {
                        logger_1.default.warn("can-i-deploy produced additional output: \n" + output.slice(0, startIndex));
                    }
                    var jsonPart = output.slice(startIndex).join('\n');
                    var parsed = JSON.parse(jsonPart);
                    if (code === 0 && parsed.summary.deployable) {
                        return deferred.resolve(parsed);
                    }
                    return deferred.reject(new CannotDeployError(parsed));
                }
                catch (e) {
                    logger_1.default.error("can-i-deploy produced non-json output:\n" + result);
                    return deferred.reject(new Error(result));
                }
            }
            if (code === 0) {
                logger_1.default.info(result);
                return deferred.resolve(result);
            }
            logger_1.default.error("can-i-deploy did not return success message:\n" + result);
            return deferred.reject(new CannotDeployError(result));
        });
        return deferred.promise.timeout(this.options.timeout, "Timeout waiting for verification process to complete (PID: " + instance.pid + ")");
    };
    return CanDeploy;
}());
exports.CanDeploy = CanDeploy;
exports.default = (function (options) { return new CanDeploy(options); });
//# sourceMappingURL=can-deploy.js.map