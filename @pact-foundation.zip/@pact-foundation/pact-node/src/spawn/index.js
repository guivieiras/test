"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
__export(require("./arguments"));
var spawn_1 = require("./spawn");
exports.default = spawn_1.default;
//# sourceMappingURL=index.js.map