import { CanDeployOptions } from '../can-deploy';
import { MessageOptions } from '../message';
import { PublisherOptions } from '../publisher';
import { ServiceOptions } from '../service';
import { VerifierOptions } from '../verifier';
export declare type CliVerbOptions = {
    cliVerb: string;
};
export declare type SpawnArgument = CanDeployOptions | MessageOptions | PublisherOptions | ServiceOptions | VerifierOptions | CliVerbOptions | {};
export declare type SpawnArguments = Array<SpawnArgument> | SpawnArgument;
export declare const DEFAULT_ARG = "DEFAULT";
export declare const PACT_NODE_NO_VALUE = "PACT_NODE_NO_VALUE";
export declare class Arguments {
    toArgumentsArray(args: SpawnArguments, mappings: {
        [id: string]: string;
    }): string[];
    private createArgumentsFromObject;
}
declare const _default: Arguments;
export default _default;
