"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
var spawn = require("cross-spawn");
var cp = require("child_process");
var path = require("path");
var logger_1 = require("../logger");
var pact_environment_1 = require("../pact-environment");
var arguments_1 = require("./arguments");
var Spawn = (function () {
    function Spawn() {
    }
    Object.defineProperty(Spawn.prototype, "cwd", {
        get: function () {
            return path.resolve(__dirname, '..');
        },
        enumerable: true,
        configurable: true
    });
    Spawn.prototype.spawnBinary = function (command, args, argMapping) {
        if (args === void 0) { args = {}; }
        if (argMapping === void 0) { argMapping = {}; }
        var envVars = JSON.parse(JSON.stringify(process.env));
        delete envVars['RUBYGEMS_GEMDEPS'];
        var opts = {
            cwd: pact_environment_1.default.cwd,
            detached: !pact_environment_1.default.isWindows(),
            env: envVars,
        };
        var spawnArgs = arguments_1.default.toArgumentsArray(args, __assign({ cliVerb: arguments_1.DEFAULT_ARG }, argMapping));
        logger_1.default.debug("Starting pact binary '" + command + "', with arguments [" + spawnArgs.join(' ') + "]");
        logger_1.default.trace("Environment: " + JSON.stringify(opts));
        var instance = spawn(command, spawnArgs, opts);
        instance.stdout.setEncoding('utf8');
        instance.stderr.setEncoding('utf8');
        instance.stdout.on('data', logger_1.default.debug.bind(logger_1.default));
        instance.stderr.on('data', logger_1.default.debug.bind(logger_1.default));
        instance.on('error', logger_1.default.error.bind(logger_1.default));
        instance.once('close', function (code) {
            if (code !== 0) {
                logger_1.default.warn("Pact exited with code " + code + ".");
            }
        });
        logger_1.default.debug("Created '" + command + "' process with PID: " + instance.pid);
        return instance;
    };
    Spawn.prototype.killBinary = function (binary) {
        if (binary) {
            var pid = binary.pid;
            logger_1.default.info("Removing Pact process with PID: " + pid);
            binary.removeAllListeners();
            try {
                pact_environment_1.default.isWindows()
                    ? cp.execSync("taskkill /f /t /pid " + pid)
                    : process.kill(-pid, 'SIGINT');
            }
            catch (e) {
                return false;
            }
        }
        return true;
    };
    return Spawn;
}());
exports.Spawn = Spawn;
exports.default = new Spawn();
//# sourceMappingURL=spawn.js.map