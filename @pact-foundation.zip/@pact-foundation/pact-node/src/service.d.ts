/// <reference types="node" />
import events = require('events');
import q = require('q');
import { CliVerbOptions } from './spawn';
import { ChildProcess } from 'child_process';
interface AbstractServiceEventInterface {
    START_EVENT: string;
    STOP_EVENT: string;
    DELETE_EVENT: string;
}
export declare abstract class AbstractService extends events.EventEmitter {
    static readonly Events: AbstractServiceEventInterface;
    readonly options: ServiceOptions;
    protected __argMapping: any;
    protected __running: boolean;
    protected __instance: ChildProcess | undefined;
    protected __cliVerb?: CliVerbOptions;
    protected __serviceCommand: string;
    protected constructor(command: string, options: ServiceOptions, argMapping: any, cliVerb?: CliVerbOptions);
    start(): q.Promise<AbstractService>;
    stop(): q.Promise<AbstractService>;
    delete(): q.Promise<AbstractService>;
    protected spawnBinary(): ChildProcess;
    protected __waitForServiceUp(): q.Promise<unknown>;
    protected __waitForServiceDown(): q.Promise<unknown>;
    private __call;
}
export interface ServiceOptions {
    port?: number;
    ssl?: boolean;
    cors?: boolean;
    host?: string;
    sslcert?: string;
    sslkey?: string;
    log?: string;
    logLevel?: LogLevel;
}
export declare type LogLevel = 'debug' | 'info' | 'warn' | 'error';
export interface HTTPConfig {
    uri: string;
    method: string;
    headers: {
        'X-Pact-Mock-Service': boolean;
        'Content-Type': string;
    };
    agentOptions?: {
        rejectUnauthorized?: boolean;
        requestCert?: boolean;
        agent?: boolean;
    };
}
export {};
