"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
var Request = require("request");
var unzipper = require("unzipper");
var tar = require("tar");
var pact_environment_1 = require("../src/pact-environment");
var chalk_1 = require("chalk");
var path = require("path");
var fs = require("fs");
var urljoin = require("url-join");
var config = require('libnpmconfig');
var sumchecker = require('sumchecker');
var request = Request.defaults({
    proxy: process.env.npm_config_https_proxy ||
        process.env.npm_config_proxy ||
        undefined,
});
exports.PACT_STANDALONE_VERSION = '1.88.49';
var PACT_DEFAULT_LOCATION = "https://github.com/pact-foundation/pact-ruby-standalone/releases/download/v" + exports.PACT_STANDALONE_VERSION + "/";
var HTTP_REGEX = /^http(s?):\/\//;
function join() {
    var paths = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        paths[_i] = arguments[_i];
    }
    return HTTP_REGEX.test(paths[0]) ? urljoin.apply(void 0, paths) : path.join.apply(path, paths);
}
function throwError(msg) {
    throw new Error(chalk_1.default.red("Error while installing binary: " + msg));
}
function getBinaryLocation(location, basePath) {
    if (!location || location.length === 0) {
        return undefined;
    }
    return HTTP_REGEX.test(location)
        ? location
        : path.resolve(basePath, location);
}
function findPackageConfig(location, tries) {
    if (tries === void 0) { tries = 10; }
    if (tries === 0) {
        return {};
    }
    var packagePath = path.resolve(location, 'package.json');
    if (fs.existsSync(packagePath)) {
        var config_1 = require(packagePath).config;
        if (config_1 && (config_1.pact_binary_location || config_1.pact_do_not_track)) {
            return {
                binaryLocation: getBinaryLocation(config_1.pact_binary_location, location),
                doNotTrack: config_1.pact_do_not_track,
            };
        }
    }
    return findPackageConfig(path.resolve(location, '..'), tries - 1);
}
function createConfig(location) {
    if (location === void 0) { location = process.cwd(); }
    var packageConfig = findPackageConfig(location);
    var PACT_BINARY_LOCATION = packageConfig.binaryLocation || PACT_DEFAULT_LOCATION;
    var CHECKSUM_SUFFIX = '.checksum';
    return {
        doNotTrack: packageConfig.doNotTrack ||
            process.env.PACT_DO_NOT_TRACK !== undefined ||
            false,
        binaries: [
            {
                platform: 'win32',
                binary: "pact-" + exports.PACT_STANDALONE_VERSION + "-win32.zip",
                binaryChecksum: "pact-" + exports.PACT_STANDALONE_VERSION + "-win32.zip" + CHECKSUM_SUFFIX,
                downloadLocation: PACT_BINARY_LOCATION,
                folderName: "win32-" + exports.PACT_STANDALONE_VERSION,
            },
            {
                platform: 'darwin',
                binary: "pact-" + exports.PACT_STANDALONE_VERSION + "-osx.tar.gz",
                binaryChecksum: "pact-" + exports.PACT_STANDALONE_VERSION + "-osx.tar.gz" + CHECKSUM_SUFFIX,
                downloadLocation: PACT_BINARY_LOCATION,
                folderName: "darwin-" + exports.PACT_STANDALONE_VERSION,
            },
            {
                platform: 'linux',
                arch: 'x64',
                binary: "pact-" + exports.PACT_STANDALONE_VERSION + "-linux-x86_64.tar.gz",
                binaryChecksum: "pact-" + exports.PACT_STANDALONE_VERSION + "-linux-x86_64.tar.gz" + CHECKSUM_SUFFIX,
                downloadLocation: PACT_BINARY_LOCATION,
                folderName: "linux-x64-" + exports.PACT_STANDALONE_VERSION,
            },
            {
                platform: 'linux',
                arch: 'ia32',
                binary: "pact-" + exports.PACT_STANDALONE_VERSION + "-linux-x86.tar.gz",
                binaryChecksum: "pact-" + exports.PACT_STANDALONE_VERSION + "-linux-x86.tar.gz" + CHECKSUM_SUFFIX,
                downloadLocation: PACT_BINARY_LOCATION,
                folderName: "linux-ia32-" + exports.PACT_STANDALONE_VERSION,
            },
        ],
    };
}
exports.createConfig = createConfig;
var CONFIG = createConfig();
var CIs = [
    'CI',
    'CONTINUOUS_INTEGRATION',
    'ABSTRUSE_BUILD_DIR',
    'APPVEYOR',
    'BUDDY_WORKSPACE_URL',
    'BUILDKITE',
    'CF_BUILD_URL',
    'CIRCLECI',
    'CODEBUILD_BUILD_ARN',
    'CONCOURSE_URL',
    'DRONE',
    'GITLAB_CI',
    'GO_SERVER_URL',
    'JENKINS_URL',
    'PROBO_ENVIRONMENT',
    'SEMAPHORE',
    'SHIPPABLE',
    'TDDIUM',
    'TEAMCITY_VERSION',
    'TF_BUILD',
    'TRAVIS',
    'WERCKER_ROOT',
];
function downloadFileRetry(url, filepath, retry) {
    if (retry === void 0) { retry = 3; }
    return new Promise(function (resolve, reject) {
        var len = 0;
        var downloaded = 0;
        var time = Date.now();
        var ca = config.read()['cafile'];
        if (ca) {
            ca = fs.readFileSync(ca);
        }
        request({
            url: url,
            headers: {
                'User-Agent': 'https://github.com/pact-foundation/pact-node',
            },
            strictSSL: config.read()['strict-ssl'],
            agentOptions: {
                ca: ca,
            },
        })
            .on('error', function (e) { return reject(e); })
            .on('response', function (res) {
            return (len = parseInt(res.headers['content-length'], 10));
        })
            .on('data', function (chunk) {
            downloaded += chunk.length;
            var now = Date.now();
            if (now - time > 1000) {
                time = now;
                console.log(chalk_1.default.gray("Downloaded " + ((100 * downloaded) / len).toFixed(2) + "%..."));
            }
        })
            .pipe(fs.createWriteStream(filepath))
            .on('finish', resolve);
    }).catch(function (e) {
        return retry-- === 0 ? throwError(e) : downloadFileRetry(url, filepath, retry);
    });
}
function download(data) {
    console.log(chalk_1.default.gray("Installing Pact Standalone Binary for " + data.platform + "."));
    return new Promise(function (resolve, reject) {
        if (fs.existsSync(path.resolve(data.filepath))) {
            console.log(chalk_1.default.yellow('Binary already downloaded, skipping...'));
            resolve(__assign({}, data, { binaryAlreadyDownloaded: true }));
            return;
        }
        console.log(chalk_1.default.yellow("Downloading Pact Standalone Binary v" + exports.PACT_STANDALONE_VERSION + " for platform " + data.platform + " from " + data.binaryDownloadPath));
        if (!CONFIG.doNotTrack) {
            console.log(chalk_1.default.gray('Please note: we are tracking this download anonymously to gather important usage statistics. ' +
                "To disable tracking, set 'pact_do_not_track: true' in your package.json 'config' section."));
            var isCI = CIs.some(function (key) { return process.env[key] !== undefined; });
            request
                .post({
                url: 'https://www.google-analytics.com/collect',
                form: {
                    v: 1,
                    tid: 'UA-117778936-1',
                    cid: Math.round(2147483647 * Math.random()).toString(),
                    t: 'screenview',
                    an: 'pact-install',
                    av: require('../package.json').version,
                    aid: 'pact-node',
                    aiid: "standalone-" + exports.PACT_STANDALONE_VERSION,
                    cd: "download-node-" + data.platform + "-" + (isCI ? 'ci' : 'user'),
                    aip: true,
                },
            })
                .on('error', function () {
            });
        }
        if (HTTP_REGEX.test(data.binaryDownloadPath)) {
            downloadFileRetry(data.binaryDownloadPath, data.filepath).then(function () {
                console.log(chalk_1.default.green("Finished downloading binary to " + data.filepath));
                resolve(data);
            }, function (e) {
                return reject("Error downloading binary from " + data.binaryDownloadPath + ": " + e);
            });
        }
        else if (fs.existsSync(data.binaryDownloadPath)) {
            fs.createReadStream(data.binaryDownloadPath)
                .on('error', function (e) {
                return reject("Error reading the file at '" + data.binaryDownloadPath + "': " + e);
            })
                .pipe(fs
                .createWriteStream(data.filepath)
                .on('error', function (e) {
                return reject("Error writing the file to '" + data.filepath + "': " + e);
            })
                .on('close', function () { return resolve(data); }));
        }
        else {
            reject("Could not get binary from '" + data.binaryDownloadPath + "' as it's not a URL and does not exist at the path specified.");
        }
    });
}
function extract(data) {
    if (fs.existsSync(data.platformFolderPath)) {
        return Promise.resolve(__assign({}, data, { binaryAlreadyInstalled: true }));
    }
    if (!fs.existsSync(data.checksumFilepath)) {
        throwError("Checksum file missing from standalone directory. Aborting.");
    }
    fs.mkdirSync(data.platformFolderPath);
    console.log(chalk_1.default.yellow("Extracting binary from " + data.filepath + "."));
    var basename = path.basename(data.filepath);
    return (sumchecker('sha1', data.checksumFilepath, __dirname, basename)
        .then(function () { return console.log(chalk_1.default.green("Checksum passed for '" + basename + "'.")); }, function () {
        return throwError("Checksum rejected for file '" + basename + "' with checksum " + path.basename(data.checksumFilepath));
    })
        .then(function () {
        return data.isWindows
            ? fs
                .createReadStream(data.filepath)
                .pipe(unzipper.Extract({
                path: data.platformFolderPath,
            }))
                .on('entry', function (entry) { return entry.autodrain(); })
                .promise()
            : tar.x({
                file: data.filepath,
                cwd: data.platformFolderPath,
                preserveOwner: false,
            });
    })
        .then(function () {
        var publishPath = path.resolve(data.platformFolderPath, 'pact', 'bin', "pact-publish" + (pact_environment_1.default.isWindows() ? '.bat' : ''));
        if (fs.existsSync(publishPath)) {
            fs.unlinkSync(publishPath);
        }
        console.log(chalk_1.default.green('Extraction done.'));
    })
        .then(function () {
        console.log('\n\n' +
            chalk_1.default.bgYellow(chalk_1.default.black('### If you') +
                chalk_1.default.red(' ❤ ') +
                chalk_1.default.black('Pact and want to support us, please donate here:')) +
            chalk_1.default.blue(' http://donate.pact.io/node') +
            '\n\n');
        return Promise.resolve(data);
    })
        .catch(function (e) {
        return throwError("Extraction failed for " + data.filepath + ": " + e);
    }));
}
function getBinaryEntry(platform, arch) {
    platform = platform || process.platform;
    arch = arch || process.arch;
    for (var _i = 0, _a = CONFIG.binaries; _i < _a.length; _i++) {
        var value = _a[_i];
        if (value.platform === platform &&
            (value.arch ? value.arch === arch : true)) {
            return value;
        }
    }
    throw throwError("Cannot find binary for platform '" + platform + "' with architecture '" + arch + "'.");
}
exports.getBinaryEntry = getBinaryEntry;
function setup(platform, arch) {
    var entry = getBinaryEntry(platform, arch);
    return Promise.resolve({
        binaryDownloadPath: join(entry.downloadLocation, entry.binary),
        checksumDownloadPath: join(PACT_DEFAULT_LOCATION, entry.binaryChecksum),
        filepath: path.resolve(__dirname, entry.binary),
        checksumFilepath: path.resolve(__dirname, entry.binaryChecksum),
        isWindows: pact_environment_1.default.isWindows(platform),
        platform: entry.platform,
        arch: entry.arch,
        platformFolderPath: path.resolve(__dirname, entry.folderName),
    });
}
function downloadChecksums() {
    console.log(chalk_1.default.gray("Downloading All Pact Standalone Binary Checksums."));
    return Promise.all(CONFIG.binaries.map(function (value) {
        return setup(value.platform, value.arch).then(function (data) {
            return downloadFileRetry(data.checksumDownloadPath, data.checksumFilepath).then(function () {
                console.log(chalk_1.default.green("Finished downloading checksum " + path.basename(data.checksumFilepath)));
                return data;
            }, function (e) {
                return throwError("Error downloading checksum from " + data.checksumDownloadPath + ": " + e);
            });
        });
    })).then(function () { return console.log(chalk_1.default.green('All checksums downloaded.')); }, function (e) { return throwError("Checksum Download Failed Unexpectedly: " + e); });
}
exports.downloadChecksums = downloadChecksums;
exports.default = (function (platform, arch) {
    if (process.env.PACT_SKIP_BINARY_INSTALL === 'true') {
        console.log(chalk_1.default.yellow("Skipping binary installation. Env var 'PACT_SKIP_BINARY_INSTALL' was found."));
        return Promise.resolve({
            binaryInstallSkipped: true,
        });
    }
    return setup(platform, arch)
        .then(download)
        .then(extract)
        .then(function (d) {
        console.log(chalk_1.default.green('Pact Standalone Binary is ready.'));
        return __assign({}, d, { binaryInstallSkipped: false });
    })
        .catch(function (e) {
        return throwError("Postinstalled Failed Unexpectedly: " + e);
    });
});
//# sourceMappingURL=install.js.map