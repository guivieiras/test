export declare const PACT_STANDALONE_VERSION = "1.88.49";
export declare function createConfig(location?: string): Config;
export declare function getBinaryEntry(platform?: string, arch?: string): BinaryEntry;
export declare function downloadChecksums(): Promise<void>;
declare const _default: (platform?: string | undefined, arch?: string | undefined) => Promise<Data>;
export default _default;
export interface PackageConfig {
    binaryLocation?: string;
    doNotTrack?: boolean;
}
export interface Config {
    doNotTrack: boolean;
    binaries: BinaryEntry[];
}
export interface Data {
    binaryDownloadPath: string;
    checksumDownloadPath: string;
    filepath: string;
    checksumFilepath: string;
    platform: string;
    isWindows: boolean;
    arch?: string;
    platformFolderPath?: string;
    binaryInstallSkipped?: boolean;
    binaryAlreadyDownloaded?: boolean;
    binaryAlreadyInstalled?: boolean;
}
export interface BinaryEntry {
    platform: string;
    arch?: string;
    binary: string;
    binaryChecksum: string;
    downloadLocation: string;
    folderName: string;
}
