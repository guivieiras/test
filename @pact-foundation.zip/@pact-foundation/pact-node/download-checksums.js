require('./standalone/install').downloadChecksums();
